package com.example.himalaya

import android.animation.ObjectAnimator
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import androidx.fragment.app.Fragment

class CultureFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_culture, container, false)

        val imageView = view.findViewById<ImageView>(R.id.cultureImageView)
        val button = view.findViewById<Button>(R.id.buttonToRegion)

        var currentScale = 1f
        val scaleIncrement = 0.1f
        val maxScale = 2.0f

        imageView.setOnClickListener {
            currentScale = if (currentScale < maxScale) currentScale + scaleIncrement else 1f
            animateImage(imageView, currentScale)
        }

        button.setOnClickListener {
            (activity as MainActivity).navigateToFragment(RegionFragment())
        }

        return view
    }

    private fun animateImage(imageView: ImageView, scale: Float) {
        ObjectAnimator.ofFloat(imageView, "scaleX", scale).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            start()
        }
        ObjectAnimator.ofFloat(imageView, "scaleY", scale).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            start()
        }
    }
}